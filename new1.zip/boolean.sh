num=$1
num=$2
if [ $1 -lt 20 -a $2 -gt 100 ]
then echo "less"
else 
echo "greater"
fi
