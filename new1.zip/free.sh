echo "free space memory"
free;
echo "load on server"
cat /proc/loadavg;
