echo "add user"
read user
sudo adduser $user
echo "USER ADDED"
echo "enter group name"
read group
sudo groupadd $group
echo "GROUP CREATED"
echo "ADDING USERS TO GROUP"
sudo adduser -G $group $user
echo "USER ADDED TO THE GROUP"
